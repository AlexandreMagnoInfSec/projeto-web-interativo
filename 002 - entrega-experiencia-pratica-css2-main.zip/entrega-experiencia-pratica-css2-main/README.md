# Entrega Experiência Prática II – CSS3

Projeto desenvolvido para a disciplina **Linguagem de Estilo: Construindo Interfaces Web Modernas com CSS3**.

### Estrutura
- HTML principal: `index.html`
- Estilos CSS: `css/style.css`

### Recursos usados
- Design system com variáveis CSS
- Grid de 12 colunas e Flexbox
- Layout responsivo com 3 breakpoints
- Menu responsivo e submenu
- Botões, formulários e alertas estilizados

### Desenvolvido por:
**Alexandre Magno Mattos do Espírito Santo**
